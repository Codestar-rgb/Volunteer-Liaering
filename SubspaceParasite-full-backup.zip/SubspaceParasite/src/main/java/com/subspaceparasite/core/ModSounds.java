package com.subspaceparasite.core;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import com.subspaceparasite.SubspaceParasite;
import net.minecraftforge.registries.RegistryObject;

/**
 * Sound event registry for the SubspaceParasite mod.
 * Contains all custom sounds from the original SRP mod.
 */
public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SubspaceParasite.MOD_ID);

    // Helper method
    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                new ResourceLocation(SubspaceParasite.MOD_ID, name)));
    }

    // === Parasite Sounds ===
    public static final RegistryObject<SoundEvent> PARASITE_IDLE = register("entity.parasite.idle");
    public static final RegistryObject<SoundEvent> PARASITE_HURT = register("entity.parasite.hurt");
    public static final RegistryObject<SoundEvent> PARASITE_DEATH = register("entity.parasite.death");
    public static final RegistryObject<SoundEvent> PARASITE_ATTACK = register("entity.parasite.attack");
    public static final RegistryObject<SoundEvent> PARASITE_STEP = register("entity.parasite.step");

    // === Infected Sounds ===
    public static final RegistryObject<SoundEvent> INFECTED_IDLE = register("entity.infected.idle");
    public static final RegistryObject<SoundEvent> INFECTED_HURT = register("entity.infected.hurt");
    public static final RegistryObject<SoundEvent> INFECTED_DEATH = register("entity.infected.death");
    public static final RegistryObject<SoundEvent> INFECTED_ATTACK = register("entity.infected.attack");

    // === Beckon Sounds ===
    public static final RegistryObject<SoundEvent> BECKON_IDLE = register("entity.beckon.idle");
    public static final RegistryObject<SoundEvent> BECKON_HURT = register("entity.beckon.hurt");
    public static final RegistryObject<SoundEvent> BECKON_DEATH = register("entity.beckon.death");
    public static final RegistryObject<SoundEvent> BECKON_ATTACK = register("entity.beckon.attack");

    // === Nexus Sounds ===
    public static final RegistryObject<SoundEvent> NEXUS_IDLE = register("entity.nexus.idle");
    public static final RegistryObject<SoundEvent> NEXUS_HURT = register("entity.nexus.hurt");
    public static final RegistryObject<SoundEvent> NEXUS_DEATH = register("entity.nexus.death");

    // === Rooter Sounds ===
    public static final RegistryObject<SoundEvent> ROOTER_IDLE = register("entity.rooter.idle");
    public static final RegistryObject<SoundEvent> ROOTER_HURT = register("entity.rooter.hurt");
    public static final RegistryObject<SoundEvent> ROOTER_ATTACK = register("entity.rooter.attack");

    // === Dispatcher Sounds ===
    public static final RegistryObject<SoundEvent> DISPATCHER_IDLE = register("entity.dispatcher.idle");
    public static final RegistryObject<SoundEvent> DISPATCHER_HURT = register("entity.dispatcher.hurt");
    public static final RegistryObject<SoundEvent> DISPATCHER_ATTACK = register("entity.dispatcher.attack");

    // === Assimilated Mob Sounds ===
    public static final RegistryObject<SoundEvent> ASSIMILATED_IDLE = register("entity.assimilated.idle");
    public static final RegistryObject<SoundEvent> ASSIMILATED_HURT = register("entity.assimilated.hurt");
    public static final RegistryObject<SoundEvent> ASSIMILATED_DEATH = register("entity.assimilated.death");

    // === Block Sounds ===
    public static final RegistryObject<SoundEvent> BLOCK_INFEST = register("block.infest");
    public static final RegistryObject<SoundEvent> BLOCK_DEINFEST = register("block.deinfest");
    public static final RegistryObject<SoundEvent> BLOCK_PARASITE_BREAK = register("block.parasite.break");
    public static final RegistryObject<SoundEvent> BLOCK_PARASITE_STEP = register("block.parasite.step");
    public static final RegistryObject<SoundEvent> BLOCK_PARASITE_PLACE = register("block.parasite.place");

    // === Item Sounds ===
    public static final RegistryObject<SoundEvent> ITEM_LIVING_ARMOR_EQUIP = register("item.living_armor.equip");
    public static final RegistryObject<SoundEvent> ITEM_SENTIENT_ARMOR_EQUIP = register("item.sentient_armor.equip");

    // === Biome Heart Sounds ===
    public static final RegistryObject<SoundEvent> BIOME_HEART_BEAT = register("block.biome_heart.beat");
    public static final RegistryObject<SoundEvent> BIOME_HEART_DEATH = register("block.biome_heart.death");

    // === Colony Sounds ===
    public static final RegistryObject<SoundEvent> COLONY_HEART_IDLE = register("block.colony_heart.idle");
    public static final RegistryObject<SoundEvent> COLONY_OUTPOST_IDLE = register("block.colony_outpost.idle");

    // === Evolution Sounds ===
    public static final RegistryObject<SoundEvent> EVOLUTION_UPGRADE = register("evolution.upgrade");
    public static final RegistryObject<SoundEvent> EVOLUTION_LEVEL = register("evolution.level");

    // === Ambient Sounds ===
    public static final RegistryObject<SoundEvent> AMBIENT_PARASITE = register("ambient.parasite");
    public static final RegistryObject<SoundEvent> AMBIENT_SPORE = register("ambient.spore");

    // === Projectile Sounds ===
    public static final RegistryObject<SoundEvent> PROJECTILE_HIT = register("entity.projectile.hit");
    public static final RegistryObject<SoundEvent> PROJECTILE_SHOOT = register("entity.projectile.shoot");

    // === Feral Sounds ===
    public static final RegistryObject<SoundEvent> FERAL_IDLE = register("entity.feral.idle");
    public static final RegistryObject<SoundEvent> FERAL_HURT = register("entity.feral.hurt");
    public static final RegistryObject<SoundEvent> FERAL_ATTACK = register("entity.feral.attack");

    // === Ancient Sounds ===
    public static final RegistryObject<SoundEvent> ANCIENT_IDLE = register("entity.ancient.idle");
    public static final RegistryObject<SoundEvent> ANCIENT_HURT = register("entity.ancient.hurt");

    // === Preeminent Sounds ===
    public static final RegistryObject<SoundEvent> PREEMINENT_IDLE = register("entity.preeminent.idle");
    public static final RegistryObject<SoundEvent> PREEMINENT_HURT = register("entity.preeminent.hurt");

    // === Abomination Sounds ===
    public static final RegistryObject<SoundEvent> ABOMINATION_IDLE = register("entity.abomination.idle");
    public static final RegistryObject<SoundEvent> ABOMINATION_HURT = register("entity.abomination.hurt");
    public static final RegistryObject<SoundEvent> ABOMINATION_DEATH = register("entity.abomination.death");

    // === Alveoli Sounds ===
    public static final RegistryObject<SoundEvent> ALVEOLI_HATCH = register("block.alveoli.hatch");

    private ModSounds() {
        // Utility class - prevent instantiation
    }
}
